create function mt_mark_event_progression(name character varying, last_encountered bigint) returns void
    language plpgsql
as
$$
BEGIN
INSERT INTO leave_system_write.mt_event_progression (name, last_seq_id, last_updated) VALUES (name, last_encountered, transaction_timestamp())
  ON CONFLICT ON CONSTRAINT pk_mt_event_progression
  DO UPDATE SET last_seq_id = last_encountered, last_updated = transaction_timestamp();

END;

$$;

alter function mt_mark_event_progression(varchar, bigint) owner to postgres;

