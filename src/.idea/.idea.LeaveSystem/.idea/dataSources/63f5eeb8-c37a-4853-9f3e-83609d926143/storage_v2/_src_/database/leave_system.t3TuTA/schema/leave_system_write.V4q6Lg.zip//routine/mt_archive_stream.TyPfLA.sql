create function mt_archive_stream(streamid uuid) returns void
    language plpgsql
as
$$
BEGIN
  update leave_system_write.mt_streams set is_archived = TRUE where id = streamid;
  update leave_system_write.mt_events set is_archived = TRUE where stream_id = streamid;
END;
$$;

alter function mt_archive_stream(uuid) owner to postgres;

