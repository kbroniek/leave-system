create function mt_upsert_leaverequestshortinfo(doc jsonb, docdotnettype character varying, docid uuid, docversion uuid) returns uuid
    language plpgsql
as
$$
DECLARE
  final_version uuid;
BEGIN
INSERT INTO leave_system_read.mt_doc_leaverequestshortinfo ("data", "mt_dotnet_type", "id", "mt_version", mt_last_modified) VALUES (doc, docDotNetType, docId, docVersion, transaction_timestamp())
  ON CONFLICT ON CONSTRAINT pkey_mt_doc_leaverequestshortinfo_id
  DO UPDATE SET "data" = doc, "mt_dotnet_type" = docDotNetType, "mt_version" = docVersion, mt_last_modified = transaction_timestamp();

  SELECT mt_version FROM leave_system_read.mt_doc_leaverequestshortinfo into final_version WHERE id = docId ;
  RETURN final_version;
END;
$$;

alter function mt_upsert_leaverequestshortinfo(jsonb, varchar, uuid, uuid) owner to postgres;

