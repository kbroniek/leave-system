create function mt_update_leaverequestshortinfo(doc jsonb, docdotnettype character varying, docid uuid, docversion uuid) returns uuid
    language plpgsql
as
$$
DECLARE
  final_version uuid;
BEGIN
  UPDATE leave_system_read.mt_doc_leaverequestshortinfo SET "data" = doc, "mt_dotnet_type" = docDotNetType, "mt_version" = docVersion, mt_last_modified = transaction_timestamp() where id = docId;

  SELECT mt_version FROM leave_system_read.mt_doc_leaverequestshortinfo into final_version WHERE id = docId ;
  RETURN final_version;
END;
$$;

alter function mt_update_leaverequestshortinfo(jsonb, varchar, uuid, uuid) owner to postgres;

